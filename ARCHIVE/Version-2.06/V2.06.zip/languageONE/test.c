#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <arpa/inet.h>
#include <pthread.h>

#define SENDER_PORT_NUM 6000 
#define SENDER_IP_ADDR "192.136.23.20" 

void main(void)
{
int socket_fd;
int option = 1; struct sockaddr_in sa;


socket_fd = socket(PF_INET, SOCK_STREAM, 0);
if ( socket_fd < 0 ){return;}

if(setsockopt(socket_fd,SOL_SOCKET,(SO_REUSEPORT | SO_REUSEADDR),(char*)&option,sizeof(option)) < 0)
	{return;}

memset(&sa, 0, sizeof(struct sockaddr_in));
sa.sin_family = AF_INET;
sa.sin_addr.s_addr = inet_addr(SENDER_IP_ADDR);
sa.sin_port = htons(SENDER_PORT_NUM);


if (bind(socket_fd, (struct sockaddr *)&sa, sizeof(struct sockaddr_in)) == -1)
	{return;}



close(socket_fd);
}