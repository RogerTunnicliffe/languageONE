#include <stdio.h>

   int n[3]; 
   int i,j;
   int Roger();
   
int main () {


   Roger();


 
   return 0;
}

int Roger(){
	
   n[0]=0;
   n[1]=1;
   n[2]=2;
   
   i=10;
   n[1]=i;	
	
}
