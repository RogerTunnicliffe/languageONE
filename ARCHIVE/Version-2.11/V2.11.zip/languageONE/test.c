#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <stdlib.h>

	struct timeval start, stop;
	double secs = 0;
	
	char strArray[1000000][27];
	char pivotValue[27]; 
	char temp[27]; 
	int prevLeftIdx;

int moveThem(int left, int right)
{	int x;

	while (left <= right) {
         
		x = memcmp(strArray[left],pivotValue,26);
		while (x < 0) {
			left++;  
			x = memcmp(strArray[left],pivotValue,26);
		}
           
		x = memcmp(strArray[right],pivotValue,26);
		while (x > 0) {
			right--;
			x = memcmp(strArray[right],pivotValue,26);
		}
            
		if (left <= right) {
			memcpy(temp, strArray[left],27);
			memcpy(strArray[left],strArray[right],27);
			memcpy(strArray[right],temp,27);
			left++;
			right--;
		}
	}
	
	return left;
	
}

int QuickSort(int left, int right) 
{

   	if (left>=right)
   		{return 0;}
   	
    strcpy(pivotValue, strArray[(left+right)/2]);
    prevLeftIdx=moveThem(left,right);
    
    QuickSort(left,prevLeftIdx-1);
    QuickSort(prevLeftIdx,right);      
            
}


int main()
{
	
    char letters[26] = "abcdefghijklmnopqrstuvwxyz";
    char c_Null[1] = "\0";
    char word[27];
    int i,j,random;
  
  //---------------
  //Build the Array
  //---------------
    puts("Filling Array"); 
    
    gettimeofday(&start, NULL);
    srand(time(NULL));
    for (i=0;i < 1000000;i++){ 
      for (j=0;j< 26;j++){ 
        random = rand() % 24;
        word[j] = letters[random];
      }
      word[j] = *c_Null;
      strcpy(strArray[i],word);
    }   
    gettimeofday(&stop, NULL);
    secs = (double)(stop.tv_usec - start.tv_usec) / 1000000 + (double)(stop.tv_sec - start.tv_sec);
	printf("time taken %f\n",secs);
    
  //--------------
  //Sort the Array
  //--------------
    puts("Sorting"); 
    
    gettimeofday(&start, NULL);   
    QuickSort(0, 999999);   
    gettimeofday(&stop, NULL);
    secs = (double)(stop.tv_usec - start.tv_usec) / 1000000 + (double)(stop.tv_sec - start.tv_sec);
	printf("time taken %f\n",secs);
    
  
  //-------------------
  //Display some Reults
  //-------------------
   for (i=0;i<10 ;i++)
   { 
     puts(strArray[i]); 
   }

}


