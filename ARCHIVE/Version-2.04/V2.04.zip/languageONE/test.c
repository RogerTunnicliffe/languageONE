#include <sys/ioctl.h>

int main ()
{
int fd;
int opt = 1;
ioctl(fd, FIONBIO, &opt);
}